<script setup lang="ts">
import { parseSimpleSliderBlock, type ShortcodeBlock } from "~/utils/shortcode";
import { useResolvedCmsLink } from "~/composables/useResolvedCmsLink";
import { useSanitizedCmsHtml } from "~/composables/useSanitizedCmsHtml";

const props = defineProps<{
  block: ShortcodeBlock;
}>();

const section = computed(() => parseSimpleSliderBlock(props.block.raw));
const sanitizedHtml = useSanitizedCmsHtml(() => props.block.raw);
const resolveLink = useResolvedCmsLink();
const activeIndex = ref(0);
let autoplayTimer: ReturnType<typeof setInterval> | null = null;

const slides = computed(() =>
  section.value.slides.map((slide, index) => ({
    ...slide,
    id: `${index}-${slide.image?.src || slide.caption || "slide"}`,
    link: resolveLink(slide.href),
  })),
);

const stopAutoplay = () => {
  if (autoplayTimer) {
    clearInterval(autoplayTimer);
    autoplayTimer = null;
  }
};

const startAutoplay = () => {
  stopAutoplay();

  if (slides.value.length < 2) {
    return;
  }

  autoplayTimer = setInterval(() => {
    activeIndex.value = (activeIndex.value + 1) % slides.value.length;
  }, 6000);
};

const goToSlide = (index: number) => {
  activeIndex.value = index;
  startAutoplay();
};

onMounted(() => {
  startAutoplay();
});

onBeforeUnmount(() => {
  stopAutoplay();
});

watch(
  () => slides.value.length,
  () => {
    activeIndex.value = 0;
    startAutoplay();
  },
);
</script>

<template>
  <section v-if="slides.length" class="shortcode-simple-slider-native">
    <div class="simple-slider-shell">
      <article
        v-for="(slide, index) in slides"
        :key="slide.id"
        class="simple-slider-slide"
        :class="{ 'is-active': index === activeIndex }"
      >
        <div class="simple-slider-media">
          <img
            v-if="slide.image?.src"
            :src="slide.image.src"
            :alt="slide.image.alt || slide.caption || 'Slide image'"
            loading="eager"
          >

          <NuxtLink
            v-if="slide.link?.isInternal"
            :to="slide.link.href"
            class="simple-slider-media__link"
            :aria-label="slide.caption || 'Open slide'"
          />
          <a
            v-else-if="slide.link"
            :href="slide.link.href"
            class="simple-slider-media__link"
            :aria-label="slide.caption || 'Open slide'"
          />
        </div>

        <div class="simple-slider-overlay" />

        <div v-if="slide.caption" class="simple-slider-caption">
          <p>{{ slide.caption }}</p>
        </div>
      </article>

      <div v-if="slides.length > 1" class="simple-slider-controls">
        <button
          type="button"
          class="simple-slider-arrow"
          aria-label="Previous slide"
          @click="goToSlide((activeIndex - 1 + slides.length) % slides.length)"
        >
          <span>&larr;</span>
        </button>

        <div class="simple-slider-dots">
          <button
            v-for="(slide, index) in slides"
            :key="`${slide.id}-dot`"
            type="button"
            class="simple-slider-dot"
            :class="{ 'is-active': index === activeIndex }"
            :aria-label="`Go to slide ${index + 1}`"
            @click="goToSlide(index)"
          />
        </div>

        <button
          type="button"
          class="simple-slider-arrow"
          aria-label="Next slide"
          @click="goToSlide((activeIndex + 1) % slides.length)"
        >
          <span>&rarr;</span>
        </button>
      </div>
    </div>
  </section>

  <section v-else class="shortcode-simple-slider-native">
    <div v-html="sanitizedHtml" />
  </section>
</template>

<style scoped>
.shortcode-simple-slider-native {
  position: relative;
  background: #0d0907;
}

.simple-slider-shell {
  position: relative;
  min-height: min(100vh, 1100px);
  overflow: hidden;
}

.simple-slider-slide {
  position: absolute;
  inset: 0;
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.9s ease, transform 0.9s ease;
  transform: scale(1.015);
}

.simple-slider-slide.is-active {
  opacity: 1;
  pointer-events: auto;
  transform: scale(1);
}

.simple-slider-media,
.simple-slider-media img,
.simple-slider-media__link,
.simple-slider-overlay {
  position: absolute;
  inset: 0;
}

.simple-slider-media img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.simple-slider-media__link {
  z-index: 2;
}

.simple-slider-overlay {
  z-index: 1;
  background:
    linear-gradient(180deg, rgba(14, 10, 8, 0.16), rgba(14, 10, 8, 0.45)),
    radial-gradient(circle at center, rgba(255, 255, 255, 0.05), transparent 40%);
}

.simple-slider-caption {
  position: absolute;
  left: 50%;
  right: auto;
  bottom: clamp(2rem, 7vw, 4.5rem);
  z-index: 3;
  width: min(92vw, 68rem);
  transform: translateX(-50%);
  text-align: center;
}

.simple-slider-caption p {
  margin: 0;
  color: rgba(250, 245, 236, 0.96);
  font-family: "Cormorant Garamond", "Times New Roman", Georgia, serif;
  font-size: clamp(1.5rem, 3.1vw, 3rem);
  line-height: 1.14;
  letter-spacing: 0.04em;
  text-wrap: balance;
  text-shadow: 0 16px 36px rgba(0, 0, 0, 0.45);
}

.simple-slider-controls {
  position: absolute;
  left: 50%;
  bottom: 1.25rem;
  z-index: 4;
  display: flex;
  align-items: center;
  gap: 1rem;
  transform: translateX(-50%);
}

.simple-slider-arrow,
.simple-slider-dot {
  border: 0;
  cursor: pointer;
}

.simple-slider-arrow {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 2.9rem;
  height: 2.9rem;
  border-radius: 999px;
  background: rgba(252, 247, 238, 0.16);
  color: #fff5e8;
  backdrop-filter: blur(14px);
  transition: background-color 0.2s ease, transform 0.2s ease;
}

.simple-slider-arrow:hover {
  background: rgba(252, 247, 238, 0.28);
  transform: translateY(-1px);
}

.simple-slider-dots {
  display: flex;
  align-items: center;
  gap: 0.55rem;
}

.simple-slider-dot {
  width: 0.7rem;
  height: 0.7rem;
  border-radius: 999px;
  background: rgba(255, 248, 237, 0.38);
  transition: transform 0.2s ease, background-color 0.2s ease;
}

.simple-slider-dot.is-active {
  background: #f7efe1;
  transform: scale(1.18);
}

@media (max-width: 767px) {
  .simple-slider-shell {
    min-height: 82vh;
  }

  .simple-slider-controls {
    bottom: 0.9rem;
    gap: 0.75rem;
  }

  .simple-slider-arrow {
    width: 2.55rem;
    height: 2.55rem;
  }
}
</style>
